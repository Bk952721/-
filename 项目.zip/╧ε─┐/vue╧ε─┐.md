# 旅途项目

## 创建项目 

方案 1：使用  vue CLLJ脚手架  

​				基于 webpack

​				命令： vue create

> 方案二 使用  creatr-vue
>
> ​			基于vite工具
>
> ​			命令： npm init vue@latest

项目名：xm_journey

​					进入项目文件

​					添加依赖  ：npm install  

​					运行           ：  npm  run dev

![image-20221002125334398](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002125334398.png)





## 开始：

​		1.配置默认图标

![image-20221002130015840](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002130015840.png)

更换标题

![image-20221002130443308](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002130443308.png)



配置jsconfig.json

从其他项目里拿

![image-20221002130732615](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002130732615.png)



### 对目录划分

​         **一般命名：**

- assets                                  存放 资源   如 img /css/或者一些字体
- components                       抽取公用组件  **[里面可以包含]**
  - common            多个项目公共组件
  - content               当前多个页面公用组件
-  hooks                                    多个组件公用  逻辑
- mock                                       模拟数据
- router                                      路由相关
- service                                    网络请求
- store                                        状态管理
- utils                                          工具                                   
- views                                        大页面



### 重置css样式

引入

 npm install normalize.css

![image-20221002164417216](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002164417216.png)



配置默认css

![image-20221002164928211](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002164928211.png)



为例防止在main.js 中引入过度的css样式

在assets的css中创建index.css 让后将其它的css样式引入

![image-20221002165512592](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002165512592.png)



## 全家同配置

### 路由：

安装：

 		npm install vue-router

在router配置：

![image-20221002173428244](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002173428244.png)



导入路由

![image-20221002170412221](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002170412221.png)





### 创建页面 

目前估计有4个

![image-20221002170513343](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002170513343.png)



在views里创建4个文件加

home        首页

favor         收藏

order        订单

message  消息

方便组件管理

![image-20221002171155036](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002171155036.png)

测试跳转

![image-20221002174023489](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002174023489.png)







### 状态管理   pinia

安装 pinia

​		npm install pinia

在store里

​		创建pinia的文件

![image-20221002174552789](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002174552789.png)

在main.js导入

![image-20221002174811459](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002174811459.png)



在store文件夹里创建一个modules 文件夹  用来存放各种模块  

比如存储搜索模块，，，

![image-20221002175036367](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002175036367.png)



## 开发底部切换导航

### 方法1   自己一步步搭建

tabbar

创建对应文件夹

![image-20221002175545403](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002175545403.png)



安装  less依赖   帮助编译

 npm install less -D

基本搭建

```vue
<template>
  <div class="tab-bar">
    <!-- 底部导航栏 -->
    <div class="tabbar-itrm">
      <img src="src\assets\img\tabbar\tab_home.png" alt="">
      <span class="text">首页</span>
    </div>
    <div class="tabbar-itrm">
      <img src="src\assets\img\tabbar/tab_favor.png" alt="">
      <span class="text">收藏</span>
    </div>

    <div class="tabbar-itrm">
      <img src="src\assets\img\tabbar/tab_order.png" alt="">
      <span class="text">订单</span>
    </div>

    <div class="tabbar-itrm">
      <img src="src\assets\img\tabbar/tab_message.png" alt="">
      <span class="text">信息</span>
    </div>
  </div>
</template>

<script setup>


</script>

<style lang="less" scoped>
.tab-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 50px;
  display: flex;
  border-top: 1px solid blue;

  .tabbar-itrm {
    flex: 1;
    display: flex;
    // 改变成列布局
    flex-direction: column;
    justify-content: center;
    align-items: center;

    .text {
      font-size: 12px;
      margin-top: 2px;
    }

    img {
      width: 32px;
    }

  }
}
</style>
```

### 方法二 抽取相同部分  利用 v-for

抽取精炼化

在assets 创建一个data文件夹用来存储本地文件



![image-20221002183810136](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002183810136.png)

引入抽取的数据

![image-20221002184025642](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002184025642.png)



![image-20221002190822885](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002190822885.png)

![image-20221002190914507](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002190914507.png)



制作效果  ，点击后改变文字颜色

![image-20221002192106490](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002192106490.png)

![image-20221002192144655](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002192144655.png)

改变图片

![image-20221002192636237](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002192636237.png)

点击事件  点击后能改变图片和文字的样式





useRouter（跳转）, useRoute（获取路由参数）!!!

使用路由切换页面内容

![image-20221002220259223](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002220259223.png)



引入vant插件   一个ui库吧   ？？

​	安装：    npm i vant 

​					npm i unplugin-vue-components -D

​		配置  vite.config.js

![image-20221002221252245](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002221252245.png)





### 方法三  利用  vant  库

修改样式方法：

![image-20221002230600925](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002230600925.png)



![image-20221002230826634](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221002230826634.png)





## 开始制作首页：

封装头部

​		抽取出来  在home 文件夹中创建cpns 文件夹  用于存放home的各个组件

目前：头部

```vue
<template>
  <div class="nav-bar">
    <span class="title">旅 途 网</span>
  </div>
</template>

<script setup>


</script>

<style lang="less" scoped>
.nav-bar {
  height: 50px;
  text-align: center;
  line-height: 50px;
  background-color: antiquewhite;
  color: orange;

  .title {
    font-size: 30px;
    font-weight: 700;
  }
}
</style>
```

![image-20221003004816011](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003004816011.png)



封装搜索部分

![image-20221003085446385](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003085446385.png)



### 切换页面时消除tabbat 

方案一

在路由页面

```
 {    path: '/city',
      component: () => import('@/views/city/city.vue'),
      // 隐藏tab-bat 方案1  传递hideTabBar   使用v-if 进行判断
      // 其他未定义的 默认是undefined  也就是false
      meta:
      {
        hideTabBar: true  }
    }
```

app页面

![image-20221003092920753](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003092920753.png)

```vue
<template>
  <div class="app">
    <!-- 展位符  使用路由做组件切换换 -->
    <router-view></router-view>

    <!-- 底部导航栏 -->
    <TabBar v-if="!route.meta.hideTabBar" />
    <!--
      hideTabBar 默认是undefind    取反就是默认显示
      在city 里设置为ture  取反后就是false 就不会显示
    -->

  </div>
</template>
    
<script setup>
// 导入tab-bar 组件
import TabBar from ' ./components/tab-bar/tab-bar03.vue' 
// 方案1隐藏tabbat方式  app页面  ----还哟个一个设置在路由里
import { useRoute } from 'vue-router';//使用useRoute
const route=useRoute()
</script>
<style scoped>

</style>

```

方案二

在city  添加样式

```js
<style lang="less" scoped>
 .city {
如果其他页面要写  使用起来就较为麻烦 可以抽取
  position: relative;
  z-index: 999;
  height: 100vh;
  background-color: white;
  overflow: auto;
} 
</style>
```

![image-20221003095618489](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003095618489.png)

### 开发city页面

#### 搜查框

利用vant 库 导航条

![image-20221003112616602](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003112616602.png)

![image-20221003112636484](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003112636484.png)



### 从服务器获取数据

安装axios

npm install axios

​		配置axios

![image-20221003115023465](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003115023465.png)

测试获取数据 

![image-20221003115109117](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003115109117.png)

不足：可能现需要获取多个数据   多次放请求  导致管理困难

可以抽取 封装

在service文件夹中创建一个modules文件集中管理里对数据的请求   

使用的时候  导入模块  使用方法就可以了

![image-20221003115944335](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003115944335.png)



这时候可以这样使用了

![image-20221003120704091](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003120704091.png)

### 使用数据

​		动态获取标题名

#### ![image-20221003131348984](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003131348984.png)

方法一

![image-20221003131452648](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003131452648.png)

<img src="C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003131717865.png" alt="image-20221003131717865" style="zoom:150%;" />

写法还是比较麻烦  故用 v-for  遍历   

遍历数组    （item ,index） in  Array

遍历对象     （value,key ,index） in Object   **（这里是遍历对象）**

![image-20221003132352907](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003132352907.png)

这样写的缺点：

如果网络请求很多  页面组件就包含大量的数据处理   （不好维护）

如果里面的     子组件需要数据  就要  传递过去  （props）  不方便

再次抽取到状态管理中：（pinia）

![image-20221003134613351](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003134613351.png)

结果：

![image-20221003134918870](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003134918870.png)



![image-20221003135032293](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003135032293.png)

















```vue
<!-- 隐藏tab-bat 

  1.1方案  添加路由设置  （看router index文件）看app.vue   
  1.2 方案2  详情看下面的css
-->
<template>
  <div class="city top-page">
    <!-- 利用vant 添加搜索框 添加圆角  取消 -->
    <!-- 监听取消按钮的点击   点击取消返回上一层 -->
    <van-search v-model="searchvalue" show-action shape="round" @click="cancel" placeholder="城市/区域" />
    <!-- tab切换 -->
    <van-tabs v-model:active="tabActive" color="#ff9854">
      <!-- 动态改变   借助？. 语法   有就显示 没有就不限     开始时默认传入underfind
      <van-tab :title="allcity?.cityGroup?.title"> </van-tab>
      <van-tab :title="allcity?.cityGroupOverSea?.title"> </van-tab>
    -->
      <template v-for="(value,key,index) in allcitys" :ke=key>
        <van-tab :title="value.title"> </van-tab>
      </template>
    </van-tabs>
  </div>
</template>

<script setup>
// 响应式添加搜括框
import { ref } from 'vue';
// 返回上一层 需要用到路由
import { useRouter } from 'vue-router';
/* 发送网络请求  方案1
import HYRequest from '@/service/request/index' */
// 方案二
import { getCityAll } from '@/service/modules/city'

// 引入状态管理  pinia
import usecitystore from '@/store/modules/city'
import { storeToRefs } from 'pinia';

const searchvalue = ref('')
// tab切换
const tabActive = ref()

// 获取useRouter
const router = useRouter()
// 点击取消按钮返回上一层
const cancel = () => {
  router.go(-1)
}

/*发送网络请求  获取数据  方案1
HYRequest.get({
  url: '/city/all'
}).then(res => {
  console.log(res);
}) */
// 方案二   保存数据  使用
// const allcity = ref({})//ref 默认时underfind
// getCityAll().then(res => {
//   allcity.value = res.data
// })


// 从store  获取数据
const citystore = usecitystore()
citystore.allcitysdata()
const { allcitys } = storeToRefs(citystore) 




</script>

<style lang="less" scoped>
/* .city {
  position: relative;
  z-index: 999;
  height: 100vh;
  background-color: white;
  overflow: auto;
} */
</style>
```

## 固定头部

方案一  利用定位

![image-20221003140343676](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003140343676.png)

方案二  局部滚动

设置高度   再设置 overfloat :about

![image-20221003140445967](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221003140445967.png)



## 展示城市数据

![image-20221004004512290](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004004512290.png)



### 组件部分

![image-20221004004929819](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004004929819.png)![image-20221004010033446](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004010033446.png)

![image-20221004005316985](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004005316985.png)

### store 里的city

![image-20221004005523129](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004005523129.png)

### 网络请求里的

service里的

![image-20221004005651973](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004005651973.png)

### 添加路由

![image-20221004005754074](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004005754074.png)



## 首页日期选择：

格式化日期

安装 库

​		npm install dayjs

再工具文件创建一个格式化 时间  和计算时差的函数

![image-20221004223637014](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004223637014.png)

设置日期相关的动态获取以及响应式

![image-20221004223832721](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004223832721.png)

![image-20221004224122215](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221004224122215.png)



## 热门推荐（使用网络请求）

![image-20221005020622960](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005020622960.png)

抽取封装

![image-20221005104801910](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005104801910.png)



![image-20221005104929614](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005104929614.png)



![image-20221005105045173](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005105045173.png)



![image-20221005105121293](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005105121293.png)



## 首页列表数据

点击首页的搜索后跳转页面 

![image-20221005124720632](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005124720632.png)



创建页面

![image-20221005124743015](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005124743015.png)

配置路由

![image-20221005124858068](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005124858068.png)

使用路由实现跳转并传递信息

![image-20221005130349544](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005130349544.png)



![image-20221005130415586](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005130415586.png)





## 设置首页中分类栏

设置网络请求：

​			![image-20221005132357573](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005132357573.png)

 

再store里存储网请求数据

​		![image-20221005132546850](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005132546850.png)

再home发送网络请求

​		![image-20221005132823656](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005132823656.png)



展示分类：

​		封装成一个组件

![image-20221005155019460](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005155019460.png)

![image-20221005155035333](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005155035333.png)





## 热门精选模块

抽取封装成组件：

![image-20221005205030452](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005205030452.png)



![image-20221005222324950](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005222324950.png)



![image-20221005222407271](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005222407271.png)





![image-20221005222538958](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005222538958.png)



![image-20221005222703667](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005222703667.png)

滑动到底部自动添加数据

![image-20221005224208967](C:\Users\11981\AppData\Roaming\Typora\typora-user-images\image-20221005224208967.png)



## 详情页：

封装跳转页面时等待













































































