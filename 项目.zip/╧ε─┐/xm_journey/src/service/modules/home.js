// 主页人热门推荐
import HYRequest from '../request'

// 热门推荐城市
export function gethothome() {
  return HYRequest.get({
    url: '/home/hotSuggests'
  })
}
// 推荐类别
export function getfenlei() {
  return HYRequest.get({
    url: '/home/categories'
  })
}
// 请求房屋列表
// 定义一个值设置默认为一 用传入值修改页面，获取下一页的内容，以便对数据进行追加
export function gethouselist(contenr = 1) {
  return HYRequest.get({
    url: '/home/houselist',
    params: {
      page: contenr
    }
  })
}