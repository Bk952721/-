// 关于详情请求
import HYRequest from '../request'

export function getdetailinfo(houseId) {
  return HYRequest.get({
    url: '/detail/infos',
    // 传入房子id
    params: {
      houseId
    }
  })
}   