// 关于城市请求数据
import HYRequest from '../request'

export function getCityAll() {
  return HYRequest.get({
    url: '/city/all'
  })
}  