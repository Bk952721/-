<template>
  <div class="app">
    <!-- 展位符  使用路由做组件切换换 -->
    <router-view></router-view>

    <!-- 底部导航栏 -->
    <!--  隐藏tab-bat方案1
    <TabBar v-if="!route.meta.hideTabBar" />
      hideTabBar 默认是undefind    取反就是默认显示
      在city 里设置为ture  取反后就是false 就不会显示
    -->

    <!-- 方案2 -->
    <TabBar />

    <Loagind />



  </div>
</template>
    
<script setup>
// 导入tab-bar 组件
import TabBar from './components/tab-bar/tab-bar03.vue'
/* 案1隐藏tabbat方式
// 方  app页面  ----还哟个一个设置在路由里
import { useRoute } from 'vue-router';//使用useRoute
const route = useRoute() */
import Loagind from '@/components/loading/loading.vue'
</script>


<style scoped>

</style>
