<template>
  <div class="loading" v-if="loading" @click="onclick">
    <div class="bg">
      <img src="@\assets\img\home\full-screen-loading.gif" alt="">
    </div>
  </div>
</template>




<script setup>
import { storeToRefs } from 'pinia';
import usehomeHotStore from '@/store/modules/home'
const isloagind = usehomeHotStore()
isloagind.alluijianData()
const { loading } = storeToRefs(isloagind)
const onclick = () => {
  loading.value = false
}





</script> 





<style lang="less" scoped>
.loading {
  position: fixed;
  z-index: 99;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  margin: auto;
  background-color: rgba(66, 66, 66, .3);
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 22px;
}

.bg {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 80px;
  height: 80px;
  border-radius: 15px;
  background-color: white;

  img {
    width: 70px;
    height: 70px;
  }
}
</style>