<!-- 手动搭建  配合外部引入   -->

<template>
  <div class="tab-bar">
    <!-- 底部导航栏 -->
    <template v-for="(item ,index ) in tabbar" :key="item">
      <!-- 动态变绑定css -->
      <div class="tabbar-itrm" @click="clickbt(index,item)" :class="{active:actionIndex === index}">
        <img v-if="(actionIndex !== index)" :src="getassetsURL(item.image)" alt="">
        <img v-else="(actionIndex === index)" :src="getassetsURL(item.imageAction)" alt="">
        <span class="text">{{item.text}}</span>
      </div>
    </template>
  </div>
</template>

<script setup>
import tabbar from '@/assets/data/tabdata.js'
// 引入ref
import { ref } from 'vue'
import { useRouter } from 'vue-router';
// 要动态加载图片路径的话    不需要过于注意
const getassetsURL = (image) => {
  // new URL  两个参数  
  // 1.相对路径 
  // 2.当前路径的url
  return new URL(`../../assets/img/${image}`, import.meta.url).href
}
// 点击时使用路由
const router = useRouter()
const actionIndex = ref(0)

function clickbt(index, item) {
  actionIndex.value = index
  router.push(item.path)
}
</script>

<style lang="less" scoped>
.tab-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 50px;
  display: flex;
  border-top: 1px solid blue;

  .tabbar-itrm {
    flex: 1;
    display: flex;
    // 改变成列布局
    flex-direction: column;
    justify-content: center;
    align-items: center;

    &.active {
      // 调用库里的颜色
      color: var(--primary-color);
    }

    .text {
      font-size: 12px;
      margin-top: 2px;
    }

    img {
      width: 32px;
    }

  }
}
</style>