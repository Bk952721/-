<!-- 手动搭建-->

<template>
  <div class="tab-bar">
    <!-- 底部导航栏 -->
    <div class="tabbar-itrm" @click="itemClick('/home')">
      <img src="@/assets\img\tabbar\tab_home.png" alt="">
      <span class="text">首页</span>
    </div>
    <div class="tabbar-itrm" @click="itemClick('/favor')">
      <img src="@/assets\img\tabbar/tab_favor.png" alt="">
      <span class="text">收藏</span>
    </div>

    <div class="tabbar-itrm" @click="itemClick('/order')">
      <img src="@/assets\img\tabbar/tab_order.png" alt="">
      <span class="text">订单</span>
    </div>

    <div class="tabbar-itrm" @click="itemClick('/message')">
      <img src="@/assets\img\tabbar/tab_message.png" alt="">
      <span class="text">信息</span>
    </div>
  </div>
</template>

<script setup>
import tabbar from '@/assets/data/tabdata'


</script>

<style lang="less" scoped>
.tab-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 50px;
  display: flex;
  border-top: 1px solid blue;

  .tabbar-itrm {
    flex: 1;
    display: flex;
    // 改变成列布局
    flex-direction: column;
    justify-content: center;
    align-items: center;

    .text {
      font-size: 12px;
      margin-top: 2px;
    }

    img {
      width: 32px;
    }

  }
}
</style>