<!-- 使用vant  Ui -->


<template>
  <div class="tab-bar">
    <!-- <van-tabbar v-model="actionIndex">
      <van-tabbar-item icon="home-o">
        默认提供了插槽  这是写死的的
        <span>首页</span>
        <template #icon>
          <img v-if="(actionIndex !== index)" :src="getassetsURL('tabbar/tab_home.png')" alt="">
          <img v-else="(actionIndex === index)" :src="getassetsURL(item.imageAction)" alt="">
        </template>
      </van-tabbar-item>
    </van-tabbar> -->
    <!-- 利用v-for  -->
    <van-tabbar v-model="actionIndex" active-color="orange">
      <template v-for="(item,index) in tabbar">
        <van-tabbar-item icon="home-o" :to="item.path">
          <span>{{item.text}}</span>
          <template #icon>
            <img v-if="(actionIndex !== index)" :src="getassetsURL(item.image)" alt="">
            <img v-else="(actionIndex === index)" :src="getassetsURL(item.imageAction)" alt="">
          </template>
        </van-tabbar-item>
      </template>
    </van-tabbar>
  </div>
</template>
<script setup>
import tabbar from '@/assets/data/tabdata.js'
import { ref } from 'vue'
const getassetsURL = (image) => {
  return new URL(`../../assets/img/${image}`, import.meta.url).href
}
const actionIndex = ref(0)
</script> 

<style lang="less" scoped>
.tab-bar {

  // 要修改高度可以覆盖
  img {
    height: 30px;
  }
}
</style>