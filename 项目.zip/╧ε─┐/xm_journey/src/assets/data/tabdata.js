const tabData = [
  {
    text: '首页',//文本
    image: 'tabbar/tab_home.png',//图片
    imageAction: 'tabbar/tab_home_active.png',//变化图片
    path: '/home'//路由跳转
  },
  {
    text: '收藏',
    image: 'tabbar/tab_favor.png',
    imageAction: 'tabbar/tab_favor_active.png',
    path: '/favor'
  },
  {
    text: '订单',
    image: 'tabbar/tab_order.png',
    imageAction: 'tabbar/tab_order_active.png',
    path: '/order'
  },
  {
    text: '信息',
    image: 'tabbar/tab_message.png',
    imageAction: 'tabbar/tab_message.png',
    path: '/message'
  },

]

export default tabData
