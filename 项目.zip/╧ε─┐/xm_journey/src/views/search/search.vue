<!-- 点击首页的搜索后跳转页面 -->
<template>
  <div class="search top-page">
    <!-- 获取从路由传入的值 -->
    <h2>获取开始时间：{{$route.query.startDate}}</h2>
    <h2>结束时间：{{$route.query.entDate}}</h2>
    <h2>城市：{{$route.query.xzcity}}</h2>
  </div>

  <div class="content">
    hhh
  </div>
</template>

<script setup>


</script>

<style lang="less" scoped>
.content {
  height: calc(100vh - 100px);
  overflow: auto;
}
</style>