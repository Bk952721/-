<template>
  <div class="order">
    order
    
  </div>
</template>

<script setup>


</script>

<style scoped>

</style>