<!-- 封装册城市组件 -->
<template>
  <div class="city-ground">
    <van-index-bar :stick="false" :index-list="indexList">
      <van-index-anchor index="热门" />
      <div class="list">
        <template v-for="(city,index) in groupData.hotCities" :key="index">
          <div class="city" @click="cityClick(city)">
            {{city.cityName}}
          </div>
        </template>
      </div>
      <template v-for="(group,index) in groupData.cities" :key="index">
        <van-index-anchor :index="group.group" />
        <template v-for="(city,indexy) in group.cities" :key="indexy">
          <van-cell :title="city.cityName" @click="cityClick(city)" />
        </template>
      </template>
    </van-index-bar>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router';
import usecitystore from '@/store/modules/city'

const props = defineProps({
  groupData: Object,
  default: () => ({})
})

//封装侧脸栏标题   A-zd的 
const indexList = computed(() => {
  const list = props.groupData.cities.map(item => item.group)
  // 再前面添加热门标签
  list.unshift('#')
  return list
})

const router = useRouter()
const cityStore = usecitystore()


// 监听点击事件
function cityClick(city) {
  // 选中当前城市
  console.log(city);
  // 将选中的城市返回到store里公用
  cityStore.xzcity = city


  // 将数据返回到上一级
  router.back()
}
</script>

<style lang="less" scoped>
.list {
  display: flex;
  justify-content: space-around;
  padding: 10px;
  padding-right: 25px;
  flex-wrap: wrap;

  .city {
    margin-top: 10px;
    margin-bottom: 10px;
    width: 80px;
    height: 25px;
    border-radius: 14px;
    font-size: 12px;
    text-align: center;
    line-height: 25px;
    background-color: #fff4ec;
  }
}
</style>