<!-- 隐藏tab-bat 

  1.1方案  添加路由设置  （看router index文件）看app.vue   
  1.2 方案2  详情看下面的css
-->
<template>
  <div class="city top-page">
    <!-- 顶内容 -->
    <div class="top">
      <!-- 利用vant 添加搜索框 添加圆角  取消 -->
      <!-- 监听取消按钮的点击   点击取消返回上一层 -->
      <van-search v-model="searchvalue" show-action shape="round" @click="cancel" placeholder="城市/区域" />
      <!-- tab切换 -->
      <van-tabs v-model:active="tabActive" color="#ff9854">
        <template v-for="(value,key,index) in allcitys" :ke=key>
          <van-tab :title="value.title" :name="key"> </van-tab>
        </template>
      </van-tabs>
    </div>
    <!-- 中心内容 -->
    <div class="content">
      <cityxx :groupData="currentGroup" />
    </div>
  </div>

</template>

<script setup>
// 响应式添加搜括框
import { ref, computed } from 'vue';
// 返回上一层 需要用到路由
import { useRouter } from 'vue-router';
// 引入状态管理  pinia
import usecitystore from '@/store/modules/city'
import { storeToRefs } from 'pinia';

// 引入组件
import cityxx from './cpns/city_group.vue'

const searchvalue = ref('')
// tab切换
const tabActive = ref()
// 获取useRouter
const router = useRouter()
// 点击取消按钮返回上一层
const cancel = () => {
  router.go(-1)
}


// 从store  获取数据
const citystore = usecitystore()
citystore.allcitysdata()
const { allcitys } = storeToRefs(citystore)

// 目的： 获取选中标签的数据
//  1 获正确的key  将tabs中绑定的tabActive 正确提取
// 2.根据key从allcitys获取数据  但获取的数据不是 向应式的 所以需要使用   computed（计算属性转化）
const currentGroup = computed(() => allcitys.value[tabActive.value])


</script>



<style lang="less" scoped>
/* .city {
  position: relative;
  z-index: 999;
  height: 100vh;
  background-color: white;
  overflow: auto;
} */
/* 固定位置方案一
.top {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
}

.content {
  margin-top: 100px;
}
 */
// 方案二  局部滚动
.content {
  height: calc(100vh - 100px);
  overflow: auto;
}
</style>