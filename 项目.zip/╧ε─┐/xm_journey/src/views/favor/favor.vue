<template>
  <div class="favor">
    favor
  </div>
</template>

<script setup>


</script>

<style scoped>

</style>