<template>

  <div class="content">
    <h2 class="title">热门精选</h2>
    <div class="list">
      <!-- 渲染列表数据 -->
      <template v-for="(item,index) in hotlist" :key="item.data.houseId">
        <!--  因为类型不一样展示的效果也不一样  所以对齐进行封装   放到components里
          <h3 v-if="item.discoveryContentType===9">typo-9{{item.data.houseName}}</h3>
        <h3 v-else-if="item.discoveryContentType===3">typo-3{{item.data.houseName}}</h3> 
      -->
        <Housev9 @click="itemclick(item.data)" v-if="item.discoveryContentType===9" :itemData='item.data' />
        <Housev3 @click="itemclick(item.data)" v-else-if="item.discoveryContentType===3" :itemData='item.data' />



      </template>
    </div>

  </div>
</template>

<script setup>
import usehomeHotStore from '@/store/modules/home'
import { storeToRefs } from 'pinia';
// 导入两个组件
import Housev3 from '@/components/house_type/typev3.vue'
import Housev9 from '@/components/house_type/typev9.vue'
import { useRouter } from 'vue-router';


// 获取数据
const homeStor = usehomeHotStore()
// 获取房子列表信息
const { hotlist } = storeToRefs(homeStor)

const route = useRouter()
const itemclick = (item) => {
  console.log(item.houseId);
  route.push("/detail/" + item.houseId)
}

</script>

<style lang="less" scoped>
.content {
  padding: 10px 8px;

  .title {
    font-size: 22px;
    padding: 10px;
  }

  .list {
    display: flex;
    flex-wrap: wrap;
  }
}
</style>