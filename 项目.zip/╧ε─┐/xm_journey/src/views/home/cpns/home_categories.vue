<!-- home  ---分类 -->
<template>
  <div class="categories">
    <template v-for="(item,index) in catgories" :key="item.id">
      <div class="item">
        <img :src="item.pictureUrl" alt="">
        <div class="text">{{item.title}}</div>
      </div>
    </template>
  </div>
</template>

<script setup>
import usehomeHotStore from '@/store/modules/home';
import { storeToRefs } from 'pinia';
const homeStore = usehomeHotStore()
const { catgories } = storeToRefs(homeStore)
</script>
<style lang="less" scoped>
.categories {
  margin-top: 10px;
  display: flex;
  overflow: auto;
  text-align: center;
  height: 80px;
  padding: 10px;
  background-color: rgba(247, 242, 242, 0.9);

  // 移动端  隐藏滚动条
  &::-webkit-scrollbar {
    display: none;
  }
  .item {
    margin-left: 10px;
    width: 70px;
    flex-shrink: 0;
    img {
      width: 32px;
      height: 32px;
    }
    .text {
      margin-top: 10px;
      font-size: 13px;
      color: orange;
    }
  }

}
</style>