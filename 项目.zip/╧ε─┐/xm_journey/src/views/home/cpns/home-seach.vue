<template>
  <div class="location">
    <!-- 点击后改变城市   位置-->
    <div class="city" @click="cityClick">{{xzcity.cityName}}</div>

    <div class="position">
      <!-- 监听点击 获取定位目前不打算做 -->
      <span class="titel" @click="positionClick">
        我的位置
      </span>
      <img src="@/assets/img/home/icon_location.png" alt="">
    </div>
  </div>

  <!-- 日期范围 -->
  <div class="section date-range bottom-gray-line ">
    <div class="start">
      <div class="date">
        <span class="tip">入住</span>
        <span class="time">{{startDate}}</span>
      </div>
      <div class="stay" @click="showCalendar=true">共{{stayDate}}晚</div>
    </div>
    <div class="end">
      <div class="date">
        <span class="tip">离店</span>
        <span class="time">{{entDate}}</span>
      </div>
    </div>
    <van-calendar color="#ff9853" type="range" v-model:show="showCalendar" @confirm="onConfirm" :show-confirm="false" />
  </div>


  <!-- 价格/人数选择 -->
  <div class="section price-counter bottom-gray-line">
    <div class="start">价格不限</div>
    <div class="end">人数不限</div>
  </div>
  <!-- 关键字 -->
  <div class="section keyword bottom-gray-line">关键字/位置/民宿名</div>

  <!-- 热门建议 -->
  <div class="section hot-suggests">
    <template v-for="(item, index) in hotSuggests" :key="index">
      <div class="item" :style="{ color: item.tagText.color, background: item.tagText.background.color }">
        {{ item.tagText.text }}
      </div>
    </template>
  </div>

  <!-- 搜索按钮 -->
  <div class="section search-btn">
    <button class="btn" @click="searchClick">开始搜索</button>
  </div>

  <!-- 类别 -->





</template>

<script setup>
// 实现点击后切换
// 一.获取函数   使用路由跳转转
import { useRouter } from 'vue-router';
// 引入sotr
import usecitystore from '@/store/modules/city'
import { storeToRefs } from 'pinia';
// 引入ref
import { ref } from 'vue';
// 引入格式化日期  工具
import { getmothday, getDiffDate } from '../../../utils/format_date'
// 导入热门推荐
import usehomeHotStore from '@/store/modules/home'



//二.获取路由
const roture = useRouter()
// 点击后跳转到新页面  
// 1.要有新页面；  2.配置路由 3.添加跳转  （完成）
const cityClick = () => {
  //三 使用push 添加跳转
  roture.push('/city')
}


// 城市设置
// 位置城市    获取位置api
const positionClick = () => {
  navigator.geolocation.getCurrentPosition((res => {
    console.log('获取位置成功', res);
  }, err => {
    console.log('获取位置失败', err);
  }))
}
// 获取当前城市
const cityStore = usecitystore()
const { xzcity } = storeToRefs(cityStore)



// 日期   设置
const nowDate = new Date()
const startDate = ref(getmothday(nowDate))
// 获取后天
const entDate = ref(getmothday(nowDate.setDate(nowDate.getDate() + 1)))
// 停留时间计算  设置默认值为1
const stayDate = ref(1)

// 使用vant里的日期组件   ref 之为真默认显示
const showCalendar = ref(false)
const onConfirm = (value) => {
  const selectStartDate = value[0]
  const selectEndDate = value[1]
  // 获取设置日期
  startDate.value = getmothday(selectStartDate)
  entDate.value = getmothday(selectEndDate)
  // 停留时间：
  stayDate.value = getDiffDate(selectStartDate, selectEndDate)
  // 点击确认后隐藏日历
  showCalendar.value = false
}

// 热门推荐   获取从父组件得到的数据
/* defineProps({
  hotSuggests: {
    type: Array,
    define: () => []
  }
}) */

const homeStore = usehomeHotStore()
// 解构获取数据
const { hotSuggests } = storeToRefs(homeStore)


// 监听点击按钮后 跳转页面
const searchClick = () => {
  // 实现跳转  并传递参数
  roture.push({
    path: '/search',
    // 传递数据
    query: {
      startDate: startDate.value,
      entDate: entDate.value,
      xzcity: xzcity.value.cityName

    }
  })
}


</script>

<style lang="less" scoped>
// 整体页面
.location {
  display: flex;
  // 垂直方向居中
  align-items: center;
  height: 44px;
  padding-left: 20px;

  .city {
    flex: 1;
  }

  .position {
    display: flex;
    align-items: center;
    width: 120px;

    .titel {
      font-size: 12px;
    }

    img {
      margin-left: 10px;
      width: 18px;
      height: 18px;
    }
  }
}

// 时间日期样式
.section {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  padding: 0 20px;
  color: #999;
  height: 44px;

  .start {
    flex: 1;
    display: flex;
    height: 44px;
    align-items: center;
  }

  .end {
    min-width: 30%;
    padding-left: 20px;
  }

  .date {
    display: flex;
    flex-direction: column;

    .tip {
      font-size: 12px;
      color: #999;
    }

    .time {
      margin-top: 3px;
      color: #333;
      font-size: 15px;
      font-weight: 500;
    }
  }
}

.date-range {
  height: 44px;

  .stay {
    flex: 1;
    text-align: center;
    font-size: 12px;
    color: #666;
  }
}

// 热门推荐按
.hot-suggests {
  margin: 10px 0;
  height: auto;

  .item {
    padding: 4px 8px;
    margin: 7px 5px;
    border-radius: 14px;
    font-size: 12px;
    line-height: 1.15;
  }
}

// 搜索按钮
.search-btn {
  .btn {
    width: 342px;
    height: 38px;
    max-height: 50px;
    font-weight: 500;
    font-size: 18px;
    line-height: 38px;
    text-align: center;
    border-radius: 20px;
    color: #fff;
    background-image: linear-gradient(90deg, #fa8c1d, #fcaf3f);
  }
}
</style>