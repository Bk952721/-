<!-- home 头部模块 -->
<template>
  <div class="nav-bar">
    <span class="title">旅 途 网</span>
  </div>
</template>

<script setup>


</script>

<style lang="less" scoped>
.nav-bar {
  height: 50px;
  text-align: center;
  line-height: 50px;
  background-color: antiquewhite;
  color: orange;

  .title {
    font-size: 30px;
    font-weight: 700;
  }
}
</style>