<template>
  <div class="home">
    <home_nav></home_nav>

    <div class="banner">
      <img src="@/assets/img/home/banner.webp" alt="">
    </div>
    <!-- 已经封装好后  不需要 通过普通方式传值了
    <home_seach :hotSuggests=hotSuggests />
    -->
    <home_seach />
    <home_categories />



    <!-- 展示房间  列表-->
    <home_content />

  </div>
</template>

<script setup>
import { ref, watch } from 'vue';
import home_nav from './cpns/home_nav.vue'//抽出头部
import home_seach from './cpns/home-seach.vue'//抽查搜索部分
import usehomeHotStore from '@/store/modules/home'//获取网络请求方式
import home_categories from "./cpns/home_categories.vue"
import home_content from "./cpns/home_content.vue"




/*  直接发送网络请求  获取数据
import HYRequest from '@/service/request/index'
发送网络请求：  热门建议  再service 的model里创建一个home存储请求
const hotSuggests = ref([])
本地模拟(直接返送网络请求)   之后再抽取
HYRequest.get({
  url: '/home/hotSuggests'
}).then(res => {
  hotSuggests.value = res.data
})

 */

// 封装后获后发网络请求获取数据
const homeHotStore = usehomeHotStore()
homeHotStore.alluijianData()
// 发送网络请求 获取分类信息
homeHotStore.fenlei()
// 发送网络请求  请求房屋列表
homeHotStore.allhouse()

// 监听window窗口的滚动       到底部自动获取新数据


window.addEventListener('scroll', () => {
  // 被卷去的高度
  const scrollTop = document.documentElement.scrollTop
  // 内容的高度
  const scrollHeight = document.documentElement.scrollHeight
  // 显示页面高度
  const boxhieght = document.documentElement.clientHeight
  if (scrollTop + boxhieght >= scrollHeight) {
    homeHotStore.allhouse()
  }
})



</script>

<style lang="less" scoped>
.banner {
  img {
    // 设置图片宽度
    width: 100%;
  }
}
</style>