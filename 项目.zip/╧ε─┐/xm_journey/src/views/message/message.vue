<template>
  <div class="message">
    message
  </div>
</template>

<script setup>


</script>

<style scoped>

</style>