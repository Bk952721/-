<template>
  <div class="detail top-page">
    <!-- <h2>获取detai切换时传入的id {{$route.params.id}}</h2> -->
    <!-- 设置导航 -->
    <van-nav-bar title="旅途" left-text="返回" left-arrow @click-left="onClickLeft" />

    <!-- 轮播图 -->
    <div class="swip" v-if="mainPart">
      <swiop :swiopData="mainPart.topModule.housePicture.housePics" />
    </div>

    <div class="infos" v-if="mainPart">
      <infos name="简介" :topInfos="mainPart.topModule" />
      <facility name="详情" :houseFacility="mainPart.dynamicModule.facilityModule.houseFacility" />
      <landlord name="房东" :landlord="mainPart.dynamicModule.landlordModule" />
      <comment name="评论" :comment="mainPart.dynamicModule.commentModule" />
      <notice name="通知" :order-rules="mainPart.dynamicModule.rulesModule.orderRules" />
      <pric name="价格" :priceIntro='mainPart.introductionModule' />



    </div>




  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { getdetailinfo } from '../../service/modules/detail'
import swiop from './cpns/detail01_swioe.vue'
import infos from './cpns/detail02_infos.vue'
import facility from './cpns/detail03_facility.vue'
import landlord from './cpns/detail04_landlord.vue'
import comment from './cpns/detail05_comment.vue'
import notice from './cpns/detail06_notice.vue'
import pric from './cpns/detail07_price.vue'




const route = useRoute()
const router = useRouter()
// 获取房间id
// console.log(route.params.id);
// 定义一个空对象 存储所以数据
const dataiInfos = ref({})//数据过于复杂 再拆解  利用计算属性

const mainPart = computed(() => dataiInfos.value.mainPart)

//发送网络请求
const houseId = route.params.id
getdetailinfo(houseId).then(res => {
  // 用空对象接收  值
  dataiInfos.value = res.data
})

// 返回首页
const onClickLeft = () => {
  router.back()
}


</script>

<style lang="less" scoped>

</style>