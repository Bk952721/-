<template>
  <div class="swipe">
    <van-swipe class="swipe_list" :autoplay="1500" indicator-color="white">
      <template v-for="(item,index) in swiopData ">
        <van-swipe-item class="item">
          <img :src="item.url" alt="">
        </van-swipe-item>
      </template>
    </van-swipe>
  </div>
</template>

<script setup>

defineProps({
  swiopData: {
    type: Array,
    default: () => []
  }
})

</script>

<style lang="less" scoped>
.swipe {
  .swipe_list {
    .item {
      img {
        width: 100%;
      }
    }
  }
}
</style>