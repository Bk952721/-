// 获取格式化日期
// 引入 
import dayjs from "dayjs";
export function getmothday(date) {
  //格式化时间
  return dayjs(date).format('MM月DD日')
}

// 获取时间差
export function getDiffDate(starDate, endDate) {
  return dayjs(endDate).diff(starDate, 'day')
}