import { createApp } from 'vue'
import App from './App.vue'
// 导入路由
import router from './router/index.js'
// 引入css样式重置
import 'normalize.css'
import './assets/css/index.css'

// 导入状态管理  pinia
import pinia from './store/index'


//              使用路由
createApp(App).use(router).use(pinia).mount('#app')
