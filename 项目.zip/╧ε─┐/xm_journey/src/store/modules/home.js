// 主页推荐
import { defineStore } from 'pinia'
import { gethothome, getfenlei, gethouselist } from '@/service/modules/home'


const usehomeHotStore = defineStore('home', {
  state: () => ({
    // 热门推荐城市
    hotSuggests: [],
    // 推荐类别
    catgories: [],


    // 定义请求页码数
    pag: 1,
    //房屋列表
    hotlist: [],

    loading: false

  }),
  actions: {
    // 获取的时城市推荐
    async alluijianData() {
      const res = await gethothome()
      this.hotSuggests = res.data
      this.loading = true
    },
    //获取 推荐类别
    async fenlei() {
      const res = await getfenlei()
      this.catgories = res.data
    },
    // 请求房屋列表
    // 定义变量  获取数据来进行追加请求页面  再获取追加页面的数据
    async allhouse() {
      const res = await gethouselist(this.pag)
      // 下拉到底部重新发送网络请求，之后获取新的数据 ，要的是以追加的形式  所以展开再追加
      this.hotlist.push(...res.data)
      // 请求完成后  页码+1
      this.pag++
    },


  }

})

export default usehomeHotStore