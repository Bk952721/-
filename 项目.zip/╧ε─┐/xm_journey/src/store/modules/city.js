import { getCityAll } from '@/service/modules/city'
import { defineStore } from 'pinia'

const usecitystore = defineStore('city', {
  state: () => ({
    allcitys: {

    },
    // 获取点击城市的数据
    xzcity: {
      // 设置一个默认值   防止进入时 空白
      cityName: '广西'
    }

  }),
  actions: {
    async allcitysdata() {
      const res = await getCityAll()
      this.allcitys = res.data
    }
  }

})

export default usecitystore