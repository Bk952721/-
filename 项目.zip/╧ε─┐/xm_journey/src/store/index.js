// 使用状态管理  pinia
// 导入
import { createPinia } from 'pinia'

const pinia = createPinia()


// 导出pinia
export default pinia