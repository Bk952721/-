// 路由
// 使用   createRouter    使用哈希（#）表示法
import { createRouter, createWebHistory } from 'vue-router'

const router = createRouter({
  // 设置方法
  history: createWebHistory(),
  // 映射关系
  routes: [
    {
      path: '/',
      redirect: '/home'
    },
    {
      path: '/home',
      component: () => import('@/views/home/home.vue')
    },
    {
      path: '/favor',
      component: () => import('@/views/favor/favor.vue')
    },
    {
      path: '/message',
      component: () => import('@/views/message/message.vue')
    },
    {
      path: '/order',
      component: () => import('@/views/order/order.vue')
    },
    {
      path: '/city',
      component: () => import('@/views/city/city.vue'),
      /* 方案1
      // 隐藏tab-bat 方案1  传递hideTabBar   使用v-if 进行判断
      // 其他未定义的 默认是undefined  也就是false
      meta:
        {
          hideTabBar: true
        } */

    }, {
      path: '/search',
      component: () => import('@/views/search/search.vue'),
    },
    ,
    {
      // 通过动态路由获取id
      path: '/detail/:id',
      component: () => import('@/views/detail/detail.vue'),

    },
  ]

})

export default router//导出路由